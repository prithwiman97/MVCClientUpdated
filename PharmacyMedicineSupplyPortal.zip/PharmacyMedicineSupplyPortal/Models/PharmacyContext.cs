﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PharmacyMedicineSupplyPortal.Models
{
    public class PharmacyContext:DbContext
    {
        public PharmacyContext(DbContextOptions options):base(options)
        {

        }
        public DbSet<MedicineSupply> MedicineSupplies { get; set; }
        public DbSet<RepSchedule> RepSchedules { get; set; }
    }
}
