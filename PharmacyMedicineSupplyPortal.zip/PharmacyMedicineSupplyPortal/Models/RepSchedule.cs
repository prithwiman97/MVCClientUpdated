﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace PharmacyMedicineSupplyPortal.Models
{
    public class RepSchedule
    {
        [Key]
        public int Id { get; set; }
        [Display(Name = "Representative Name")]
        public string RepName { get; set; }
        
        public Doctor Doctor { get; set; }

        [NotMapped]
        public IEnumerable<string> Medicine { get; set; }
        [Display(Name = "Time of Meeting")]
        public string MeetingSlot { get; set; }
        [Display(Name = "Meeting Date")]
        public DateTime DateOfMeeting { get; set; }
    }
}
