﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace PharmacyMedicineSupplyPortal.Models
{
    public class Doctor
    {
        [Display(Name = "Doctor's Name")]
        public string DoctorName { get; set; }
        [Display(Name = "Contact Number")]
        public long ContactNo { get; set; }
        [Display(Name = "Treating Ailment")]
        public string TreatingAilment { get; set; }
    }
}
