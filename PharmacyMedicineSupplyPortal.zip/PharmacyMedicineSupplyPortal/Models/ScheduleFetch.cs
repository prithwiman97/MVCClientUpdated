﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PharmacyMedicineSupplyPortal.Models
{
    public class ScheduleFetch
    {
        public string Token { get; set; }
        public DateTime FromDate { get; set; }
    }
}
