﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace PharmacyMedicineSupplyPortal.Models
{
    public class MedicineStock
    {
        public string Name { get; set; }
        [Display(Name = "Chemical Composition")]
        public string ChemicalComposition { get; set; }
        [Display(Name = "Target Ailment")]
        public string TargetAilment { get; set; }
        [Display(Name = "Expiry Date")]
        public DateTime DateOfExpiry { get; set; }
        [Display(Name = "Currently In Stock")]
        public int numberOfTabletsInStock { get; set; }
    }
}
