﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace PharmacyMedicineSupplyPortal.Models
{
    public class MedicineSupply
    {
        [Key]
        public int Id { get; set; }
        [Display(Name = "Name of Medicine")]
        public string MedicineName { get; set; }
        [Display(Name = "Demand")]
        public int DemandCount { get; set; }
        [Display(Name = "Supply")]
        public int SupplyCount { get; set; }
    }
}
