﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace PharmacyMedicineSupplyPortal.Migrations
{
    public partial class DBCreated : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Doctor",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    DoctorName = table.Column<string>(nullable: true),
                    ContactNo = table.Column<long>(nullable: false),
                    TreatingAilment = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Doctor", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "MedicineSupplies",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    MedicineName = table.Column<string>(nullable: true),
                    DemandCount = table.Column<int>(nullable: false),
                    SupplyCount = table.Column<int>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_MedicineSupplies", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "RepSchedules",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    RepName = table.Column<string>(nullable: true),
                    DoctorId = table.Column<int>(nullable: true),
                    MeetingSlot = table.Column<string>(nullable: true),
                    DateOfMeeting = table.Column<DateTime>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_RepSchedules", x => x.Id);
                    table.ForeignKey(
                        name: "FK_RepSchedules_Doctor_DoctorId",
                        column: x => x.DoctorId,
                        principalTable: "Doctor",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateIndex(
                name: "IX_RepSchedules_DoctorId",
                table: "RepSchedules",
                column: "DoctorId");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "MedicineSupplies");

            migrationBuilder.DropTable(
                name: "RepSchedules");

            migrationBuilder.DropTable(
                name: "Doctor");
        }
    }
}
