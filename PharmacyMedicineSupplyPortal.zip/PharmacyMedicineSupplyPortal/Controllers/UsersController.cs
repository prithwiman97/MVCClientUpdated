﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using PharmacyMedicineSupplyPortal.Models;

namespace PharmacyMedicineSupplyPortal.Controllers
{
    public class UsersController : Controller
    {
        private IConfiguration Configuration;
        Uri baseAddress;
        HttpClient client;
        public UsersController(IConfiguration configuration)
        {
            Configuration = configuration;
            baseAddress = new Uri(Configuration["Links:Authorization"]);
            client = new HttpClient();
            client.BaseAddress = baseAddress;
        }
        public IActionResult Login()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Authenticate(User user)
        {
            try{
                string data = JsonConvert.SerializeObject(user);
                StringContent content = new StringContent(data, Encoding.UTF8, "application/json");
                HttpResponseMessage response = client.PostAsync(client.BaseAddress, content).Result;
                if (response.IsSuccessStatusCode)
                {
                    string token = response.Content.ReadAsStringAsync().Result;
                    HttpContext.Response.Cookies.Append("token", token);
                    return RedirectToAction("Home");
                }
                ViewBag.Message = "Invalid email or password";
                return View("Login");
            }
            catch(Exception e)
            {
                return View("Error",new ErrorViewModel { RequestId="The requested service did not respond"});
            }
        }


        public IActionResult Home()
        {
            if (string.IsNullOrEmpty(HttpContext.Request.Cookies["token"]))
                return View("Login");
            return View();
        }

        public IActionResult Logout()
        {
            HttpContext.Response.Cookies.Delete("token");
            TempData["Logout"] = "You have successfully logged out";
            return RedirectToAction("Login");
        }
    }
}
