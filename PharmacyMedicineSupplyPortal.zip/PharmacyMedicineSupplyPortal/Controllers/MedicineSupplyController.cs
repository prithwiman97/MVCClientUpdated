﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using PharmacyMedicineSupplyPortal.Models;

namespace PharmacyMedicineSupplyPortal.Controllers
{
    public class MedicineSupplyController : Controller
    {
        Uri baseAddress = new Uri("https://localhost:44324/api/MedicineSupply");
        HttpClient client;
        public MedicineSupplyController()
        {
            client = new HttpClient();
            client.BaseAddress = baseAddress;
        }
        public IActionResult DemandForm()
        {
            if (!IsAuthenticated())
                return RedirectToAction("Login", "Users");
            return View();
        }

        [HttpPost]
        public IActionResult GetSupply(MedicineDemand demand)
        {
            if (!IsAuthenticated())
                return RedirectToAction("Login", "Users");
            try
            {
                string token = HttpContext.Request.Cookies["token"];
                string data = JsonConvert.SerializeObject(demand);
                StringContent content = new StringContent(data, Encoding.UTF8, "application/json");
                client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);
                HttpResponseMessage response = client.PostAsync(client.BaseAddress, content).Result;
                if (response.IsSuccessStatusCode)
                {
                    string supplyData = response.Content.ReadAsStringAsync().Result;
                    MedicineSupply supply = JsonConvert.DeserializeObject<MedicineSupply>(supplyData);
                    return View(supply);
                }
                ViewBag.Message = "Invalid Medicine name";
                return View("DemandForm");
            }
            catch(Exception e)
            {
                return View("Error", new ErrorViewModel { RequestId = "Requested Service did not respond" });
            }
        }

        private bool IsAuthenticated()
        {
            if (string.IsNullOrEmpty(HttpContext.Request.Cookies["token"]))
            {
                TempData["Unauthenticated"] = "Please Log In";
                return false;
            }
            return true;
        }
    }
}
