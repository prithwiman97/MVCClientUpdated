﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using PharmacyMedicineSupplyPortal.Models;

namespace PharmacyMedicineSupplyPortal.Controllers
{
    public class MedicineSupplyController : Controller
    {
        Uri baseAddress = new Uri("https://localhost:44324/api/MedicineSupply");
        HttpClient client;
        public MedicineSupplyController()
        {
            client = new HttpClient();
            client.BaseAddress = baseAddress;
        }
        public IActionResult DemandForm()
        {
            return View();
        }

        [HttpPost]
        public IActionResult GetSupply(MedicineDemand demand)
        {
            string token = TempData["token"].ToString();
            string data = JsonConvert.SerializeObject(demand);
            StringContent content = new StringContent(data, Encoding.UTF8, "application/json");
            client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);
            HttpResponseMessage response = client.PostAsync(client.BaseAddress,content).Result;
            if (response.IsSuccessStatusCode)
            {
                string supplyData = response.Content.ReadAsStringAsync().Result;
                MedicineSupply supply = JsonConvert.DeserializeObject<MedicineSupply>(supplyData);
                return View(supply);
            }
            ViewBag.Message = "Invalid Medicine name";
            TempData["token"] = token;
            return View("DemandForm");
        }
    }
}
