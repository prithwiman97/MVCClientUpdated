﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using PharmacyMedicineSupplyPortal.Models;
using PharmacyMedicineSupplyPortal.ViewModel;

namespace PharmacyMedicineSupplyPortal.Controllers
{
    public class MedicineSupplyController : Controller
    {
        private readonly PharmacyContext _context;
        private IConfiguration Configuration;
        Uri medicineSupply, medicineStock;
        HttpClient supplyClient,stockClient;
       
        public MedicineSupplyController(IConfiguration configuration,PharmacyContext context)
        {
            Configuration = configuration;
            _context = context;
            medicineSupply = new Uri(Configuration["Links:PharmacyMedicineSupply"]);
            medicineStock = new Uri(Configuration["Links:MedicineStock"]);
            supplyClient = new HttpClient();
            stockClient = new HttpClient();
            supplyClient.BaseAddress = medicineSupply;
            stockClient.BaseAddress = medicineStock;
        }
        public IActionResult DemandForm()
        {
            if (!IsAuthenticated())
                return RedirectToAction("Login", "Users");
            try
            {
                string token = HttpContext.Request.Cookies["token"];
                stockClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer",token);
                HttpResponseMessage response = stockClient.GetAsync(stockClient.BaseAddress).Result;
                if (response.IsSuccessStatusCode)
                {
                    string stockData = response.Content.ReadAsStringAsync().Result;
                    IEnumerable<MedicineStock> stock = JsonConvert.DeserializeObject<List<MedicineStock>>(stockData);
                    return View(stock);
                }
                return View();
            }
            catch(Exception e)
            {
                return View("Error", new ErrorViewModel { RequestId = "Requested Service did not respond" });
            }
        }

        [HttpPost]
        public IActionResult GetSupply(MedicineDemand demand)
        {
            if (!IsAuthenticated())
                return RedirectToAction("Login", "Users");
            try
            {
                string token = HttpContext.Request.Cookies["token"];
                string data = JsonConvert.SerializeObject(demand);
                StringContent content = new StringContent(data, Encoding.UTF8, "application/json");
                supplyClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);
                HttpResponseMessage response = supplyClient.PostAsync(supplyClient.BaseAddress, content).Result;
                if (response.IsSuccessStatusCode)
                {
                    string supplyData = response.Content.ReadAsStringAsync().Result;
                    MedicineSupply supply = JsonConvert.DeserializeObject<MedicineSupply>(supplyData);
                    _context.MedicineSupplies.Add(supply);
                    _context.SaveChanges();
                    return View(supply);
                }
                ViewBag.Message = "Invalid Medicine name";
                return View("DemandForm");
            }
            catch(Exception e)
            {
                return View("Error", new ErrorViewModel { RequestId = "Requested Service did not respond" });
            }
        }

        private bool IsAuthenticated()
        {
            if (string.IsNullOrEmpty(HttpContext.Request.Cookies["token"]))
            {
                TempData["Unauthenticated"] = "Please Log In";
                return false;
            }
            return true;
        }
    }
}
