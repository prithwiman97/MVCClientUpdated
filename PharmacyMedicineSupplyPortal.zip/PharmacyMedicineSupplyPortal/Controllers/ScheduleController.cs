﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using PharmacyMedicineSupplyPortal.Models;
using System.Net.Http.Headers;
using Newtonsoft.Json;

namespace PharmacyMedicineSupplyPortal.Controllers
{
    public class ScheduleController : Controller
    {
        Uri baseAddress = new Uri("https://localhost:44334/api/RepSchedule");
        HttpClient client;
        public ScheduleController()
        {
            client = new HttpClient();
            client.BaseAddress = baseAddress;
        }

        public IActionResult ScheduleForm()
        {
            if (!IsAuthenticated())
                return RedirectToAction("Login", "Users");
            return View();
        }
        public IActionResult GetSchedule(ScheduleFetch data)
        {
            if (!IsAuthenticated())
                return RedirectToAction("Login", "Users");
            HttpResponseMessage response = new HttpResponseMessage();
            try
            {
                client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", data.Token);
                response = client.GetAsync(client.BaseAddress + "/" + data.FromDate.ToString("yyyy-MM-dd")).Result;
                if (response.IsSuccessStatusCode)
                {
                    string scheduleData = response.Content.ReadAsStringAsync().Result;
                    IEnumerable<RepSchedule> schedule = JsonConvert.DeserializeObject<List<RepSchedule>>(scheduleData);
                    return View(schedule);
                }
                return View();
            }
            catch(Exception e)
            {
                
                return View("Error", new ErrorViewModel { RequestId = "Requested Service did not respond" });
            }
        }
        private bool IsAuthenticated()
        {
            if (string.IsNullOrEmpty(HttpContext.Request.Cookies["token"]))
            {
                TempData["Unauthenticated"] = "Please Log In";
                return false;
            }
            return true;
        }
    }
}
