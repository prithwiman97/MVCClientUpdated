﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using PharmacyMedicineSupplyPortal.Models;
using System.Net.Http.Headers;
using Newtonsoft.Json;
using Microsoft.Extensions.Configuration;

namespace PharmacyMedicineSupplyPortal.Controllers
{
    public class ScheduleController : Controller
    {
        private readonly PharmacyContext _context;
        private IConfiguration Configuration;
        Uri baseAddress;
        HttpClient client;
        public ScheduleController(IConfiguration configuration,PharmacyContext context)
        {
            Configuration = configuration;
            _context = context;
            baseAddress = new Uri(Configuration["Links:MedicalRepresentativeSchedule"]);
            client = new HttpClient();
            client.BaseAddress = baseAddress;
        }

        public IActionResult ScheduleForm()
        {
            if (!IsAuthenticated())
                return RedirectToAction("Login", "Users");
            return View();
        }
        public IActionResult GetSchedule(ScheduleFetch data)
        {
            if (!IsAuthenticated())
                return RedirectToAction("Login", "Users");
            HttpResponseMessage response = new HttpResponseMessage();
            try
            {
                client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", data.Token);
                response = client.GetAsync(client.BaseAddress + "/" + data.FromDate.ToString("yyyy-MM-dd")).Result;
                if (response.IsSuccessStatusCode)
                {
                    string scheduleData = response.Content.ReadAsStringAsync().Result;
                    IEnumerable<RepSchedule> schedule = JsonConvert.DeserializeObject<List<RepSchedule>>(scheduleData);
                    foreach (RepSchedule rep in schedule)
                        _context.RepSchedules.Add(rep);
                    _context.SaveChanges();
                    return View(schedule);
                    
                }
                ViewBag.Message = "Sunday starting day not possible";
                
                return View("ScheduleForm");
            }
            catch(Exception e)
            {
                
                return View("Error", new ErrorViewModel { RequestId = "Requested Service did not respond" });
            }
        }
        private bool IsAuthenticated()
        {
            if (string.IsNullOrEmpty(HttpContext.Request.Cookies["token"]))
            {
                TempData["Unauthenticated"] = "Please Log In";
                return false;
            }
            return true;
        }
    }
}
