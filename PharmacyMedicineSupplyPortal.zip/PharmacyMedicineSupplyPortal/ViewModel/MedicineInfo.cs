﻿using PharmacyMedicineSupplyPortal.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PharmacyMedicineSupplyPortal.ViewModel
{
    public class MedicineInfo
    {
        public IEnumerable<string> medname { get; set; }
        public MedicineDemand meddem { get; set; }
    }
}
